package com.example.backend4rate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Backend4rateApplicationTests {

    @Test
    void contextLoads() {
    }

}
