package com.example.backend4rate.models.enums;

public enum LogLevel {
    INFO, WARNING, ERROR
}
