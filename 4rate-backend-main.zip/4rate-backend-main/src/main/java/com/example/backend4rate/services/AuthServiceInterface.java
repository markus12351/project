package com.example.backend4rate.services;

public interface AuthServiceInterface {

}
